public class Slide {
}
